import argparse
import math
import time
import numpy as np
import random as rd
import matplotlib.pyplot as plt
import os
import torch
import torch.nn.functional as F
import torch.optim as optim
import copy
from BG_loader import BGDataset_Labled
from torch.utils.data import DataLoader
from transformer.Models import Transformer

global_step = 0
os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def generate_para():
    global global_step
    parser = argparse.ArgumentParser()

    opt = parser.parse_args()
    opt.log = True
    opt.save_mode = "best"

    opt.checkpoint_load = "AA.chkpt"

    opt.root_path_T = "YourPath"
    opt.mat_file_T = "data_OP_3_final.mat"
    opt.root_path_V = opt.root_path_T
    opt.mat_file_V = opt.mat_file_T
    opt.key_X_train = "X_train"
    opt.key_y_train = "y_train"
    opt.key_X_valid = "X_valid"
    opt.key_y_valid = "y_valid"

    opt.random_seed = 1
    opt.src_dim = 1
    opt.trg_dim = 1
    opt.seq_length = 1000  # TODO: should be changed during training

    opt.epoch = 500000

    opt.n_head = 1
    opt.n_layers = 1
    opt.batch_size = 200
    opt.d_model = 100
    opt.d_word_vec = opt.d_model
    opt.d_inner_hid = opt.d_model * 2
    opt.d_k = int(opt.d_model / opt.n_head)
    opt.d_v = opt.d_k
    opt.dropout = 0.001
    opt.LR = 2e-3

    opt.series = "Trans_OP_3_%s_%s_%s_%s_%s_%.2f"\
                 % (opt.n_head, opt.n_layers, opt.batch_size, opt.d_model, opt.LR, rd.random())

    print("Training model with series\n%s" % opt.series)

    opt.log_name = "./log/log_%s" % opt.series
    opt.save_model_name = "./model/model_%s" % opt.series

    if not os.path.exists("./log"):
        os.mkdir("./log")
    if not os.path.exists("./model"):
        os.mkdir("./model")

    return opt


def generate_model(opt, teacher=False):

    model = Transformer(
        n_src_vocab=opt.src_dim,
        n_trg_vocab=opt.trg_dim,
        d_k=opt.d_k,
        d_v=opt.d_v,
        d_model=opt.d_model,
        d_word_vec=opt.d_word_vec,
        d_inner=opt.d_inner_hid,
        n_layers=opt.n_layers,
        n_head=opt.n_head,
        n_position=opt.seq_length,
        dropout=opt.dropout).cuda()

    return model


def cal_loss(pred, real_value):
    # Calculate cross entropy loss, apply label smoothing if needed.
    loss_func = torch.nn.MSELoss(reduction="mean")
    loss = loss_func(pred, real_value)

    return loss


def train_epoch(model_S, training_data, optimizer, opt, epoch):
    ''' Epoch operation in training phase'''
    global global_step
    # global step
    model_S.train()
    total_loss = 0
    loss_pred_only = 0

    step = 0
    for src_seq, trg_seq in training_data:

        src_seq = src_seq.cuda().float()
        trg_seq = trg_seq.cuda().float()

        optimizer.zero_grad()

        trg_seq_dislocation = torch.zeros(trg_seq.size()).float()
        trg_seq_dislocation[:, 1:, :] = trg_seq[:, :-1, :]
        # trg_seq_dislocation[:, 0, :] = trg_seq_dislocation[:, 1, :]
        trg_seq_dislocation = trg_seq_dislocation.cuda()
        pred_labeled = model_S(src_seq, trg_seq_dislocation)
        loss = cal_loss(pred_labeled, trg_seq)

        loss.backward()
        # optimizer.step()
        optimizer.step()
        loss_pred_only += loss.item() * src_seq.size(0)
        step += src_seq.size(0)

    loss_pred_average = loss_pred_only / step

    return loss_pred_average


def eval_epoch(model, validation_data, device, opt, epoch):
    ''' Epoch operation in evaluation phase '''
    model.eval()

    with torch.no_grad():
        # for batch in tqdm(validation_data, mininterval=2, desc=desc, leave=False):
        total_loss = 0.0
        step_valid = 0
        for src_seq_v, trg_seq_v in validation_data:
            src_seq_v = src_seq_v.cuda().float()
            trg_seq_v = trg_seq_v.cuda().float()
            # question = question.to(device)
            trg_seq_dis_v = torch.zeros(trg_seq_v.size()).float()
            trg_seq_dis_v[:, 1:, :] = trg_seq_v[:, :-1, :]
            # trg_seq_dis_v[:, 0, :] = trg_seq_dis_v[:, 1, :]
            trg_seq_dis_v = trg_seq_dis_v.cuda()

            pred_seq_v = model(src_seq_v, trg_seq_dis_v)
            loss = cal_loss(pred_seq_v, trg_seq_v)

            total_loss += loss.item() * src_seq_v.size(0)
            step_valid += src_seq_v.size(0)

    loss_average_1 = total_loss / step_valid

    return loss_average_1


def train(model_S, training_data, validation_data, optimizer, decay_optim, device, opt):
    ''' Start training '''

    if opt.log:
        log_file = opt.log_name + '.log'
        # print('[Info] Training performance will be written to file: {}'.format(log_file))
        with open(log_file, 'w') as log_f:
            log_f.write('epoch, train_loss, valid_loss\n')

    def print_performances(header, loss, start_time):
        print('  - {header:15} : {loss: 8.5f}, ' \
              'elapse: {elapse:3.3f} min'.format(header=f"({header})", loss=loss * 1000,
                                                 elapse=(time.time() - start_time) / 60))

    valid_losses = []

    for epoch_i in range(opt.epoch):

        print("\n[Epoch Number:", epoch_i, "]")

        start = time.time()
        train_loss = train_epoch(model_S, training_data, optimizer, opt, epoch_i)
        print_performances('Training Loss', train_loss, start)

        decay_optim.step()

        start = time.time()
        valid_loss = eval_epoch(model_S, validation_data, device, opt, epoch_i)
        print_performances('Validation Loss', valid_loss, start)

        valid_losses += [valid_loss]

        checkpoint = {'epoch': epoch_i, 'settings': opt, 'model': model_S.state_dict()}

        if opt.save_mode == 'all':
            model_name = opt.save_model_name + '_loss_{valid_loss:3.10f}.chkpt'.format(valid_loss=valid_loss)
            torch.save(checkpoint, model_name)
        elif opt.save_mode == 'best':
            model_name = opt.save_model_name + '_best.chkpt'
            if valid_loss <= min(valid_losses):
                torch.save(checkpoint, model_name)
                print('  - [Info] The checkpoint file has been updated.')

        f = open(log_file, "a")
        f.write("%s," % epoch_i)
        f.write("%s," % train_loss)
        f.write("%s," % valid_loss)
        f.write("\n")
        f.close()

        stop_sgn = stop_status_check()
        if stop_sgn:
            # plot_data(log_file, opt)
            break

def prepare_dataloaders(opt):

    batch_size = opt.batch_size

    data_1 = BGDataset_Labled(opt.root_path_T, opt.mat_file_T, opt.key_X_train, opt.key_y_train)
    data_2 = BGDataset_Labled(opt.root_path_V, opt.mat_file_V, opt.key_X_valid, opt.key_y_valid)

    # test_data = SHMData(path, "test", PCA_dim, feature_dim, feature_dim, label_dim)
    iterator_1 = DataLoader(data_1, batch_size=batch_size, shuffle=True, num_workers=0)
    iterator_2 = DataLoader(data_2, batch_size=batch_size, shuffle=False, num_workers=0)

    print("dataset 1 size: %s samples" % data_1.len)
    print("dataset 2 size: %s samples" % data_2.len)

    return iterator_1, iterator_2


def stop_status_check():
    try:
        f = open("stop_sgn.txt", "r")
    except:
        stop_sgn = False
        return stop_sgn

    data = f.readline()
    if "yes" in data or "Yes" in data or "YES" in data:
        stop_sgn = True
    else:
        stop_sgn = False

    return stop_sgn


def main():
    opt = generate_para()
    device = torch.device('cuda')
    training_data, validation_data = prepare_dataloaders(opt)

    transformer = generate_model(opt, teacher=False)
    transformer = torch.nn.DataParallel(transformer).cuda()

    optimizer = optim.Adam(transformer.parameters(), lr=opt.LR, betas=(0.9, 0.99), eps=1e-09)
    decay_optim = optim.lr_scheduler.ExponentialLR(optimizer, 0.999)

    train(transformer, training_data, validation_data, optimizer, decay_optim, device, opt)

    log_file = opt.log_name + '.log'
    plot_data(log_file, opt)


if __name__ == '__main__':
    main()
