import argparse
import math
import time
import numpy as np
import random as rd
import matplotlib.pyplot as plt
import os
import torch
import torch.nn.functional as F
import torch.optim as optim
import copy
from torch.autograd import Variable
from BG_loader import BGDataset_Labled
from torch.utils.data import DataLoader
from transformer.Models import Transformer


global_step = 0
os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def generate_para():
    global global_step
    parser = argparse.ArgumentParser()

    opt = parser.parse_args()
    opt.log = True
    opt.save_mode = "best"

    opt.root_path_T = "D:/完成的科研工作/20210324 金字塔架构论文/总结与改进/Dataset_final"
    opt.mat_file_T = "data_OP_4_final.mat" # TODO: should be changed during training
    opt.root_path_V = opt.root_path_T
    opt.mat_file_V = opt.mat_file_T
    opt.series = "model_Trans_OP_4_1_1_200_100_0.001_0.86_best.chkpt" # TODO: should be changed during training

    opt.key_X_train = "X_valid"
    opt.key_y_train = "y_valid"
    opt.key_X_valid = "X_test"
    opt.key_y_valid = "y_test"
    opt.random_seed = 1

    opt.src_dim = 1 # TODO: should be changed during training
    opt.trg_dim = 1 # TODO: should be changed during training

    opt.proj_share_weight = False
    opt.embs_share_weight = False
    opt.seq_length = 1000 # TODO: should be changed during training

    opt.batch_size = 200

    opt.epoch = 500000
    opt.cuda = True

    opt.n_head = 1
    opt.n_layers = 1

    opt.d_model = 100 # TODO: should be changed during training
    opt.d_word_vec = opt.d_model
    opt.d_inner_hid = opt.d_model * 2
    opt.d_k = int(opt.d_model / opt.n_head)
    opt.d_v = opt.d_k
    opt.dropout = 0.005
    opt.LR = 1e-3

    return opt


def write_result(folder_series, series, input, output, pred):
    input = input.detach().cpu().squeeze(0).numpy()
    output = output.detach().cpu().squeeze(0).numpy()
    pred = pred.detach().cpu().squeeze(0).numpy()

    if not os.path.exists("./pred_result_%s" % folder_series):
        os.mkdir("./pred_result_%s" % folder_series)

    final_result = np.hstack((input, output, pred))
    np.savetxt("./pred_result_%s/%s.csv" % (folder_series, series), final_result, delimiter=",", fmt="%s")


def eval_epoch(model, validation_data, device, opt):
    ''' Epoch operation in evaluation phase '''
    model.eval()

    with torch.no_grad():
        # for batch in tqdm(validation_data, mininterval=2, desc=desc, leave=False):
        total_loss = 0.0
        step_valid = 0
        count = 0

        for src_seq_v, trg_seq_v in validation_data:

            src_seq_v = src_seq_v.cuda().float()
            trg_seq_v = trg_seq_v.cuda().float()
            # question = question.to(device)
            trg_seq_dis_v = torch.zeros(trg_seq_v.size()).float()
            trg_seq_dis_v[:, 1:, :] = trg_seq_v[:, :-1, :]
            # trg_seq_dis_v[:, 0, :] = trg_seq_dis_v[:, 1, :]
            trg_seq_dis_v = trg_seq_dis_v.cuda()

            pred_seq_v = model(src_seq_v, trg_seq_dis_v)
            # pred_seq_v = pred_seq_v.unsqueeze(2)
            loss = cal_loss(pred_seq_v, trg_seq_v)

            # note keeping
            # n_word_total += n_word
            # n_word_correct += n_correct
            total_loss += loss.item() * src_seq_v.size(0)
            step_valid += src_seq_v.size(0)

            for number in range(src_seq_v.size(0)):
                input = src_seq_v[number, :, :]
                output = trg_seq_v[number, :, :]
                pred = pred_seq_v[number, :, :]

                write_result(opt.folder, count, input, output, pred)
                count += 1

    loss_average_1 = total_loss / step_valid

    return loss_average_1


def prepare_dataloaders(opt):

    batch_size = opt.batch_size

    data_1 = BGDataset_Labled(opt.root_path_T, opt.mat_file_T, opt.key_X_train, opt.key_y_train)
    data_2 = BGDataset_Labled(opt.root_path_V, opt.mat_file_V, opt.key_X_valid, opt.key_y_valid)

    # test_data = SHMData(path, "test", PCA_dim, feature_dim, feature_dim, label_dim)
    iterator_1 = DataLoader(data_1, batch_size=batch_size, shuffle=True, num_workers=0)
    iterator_2 = DataLoader(data_2, batch_size=batch_size, shuffle=False, num_workers=0)

    print("dataset 1 size: %s samples" % data_1.len)
    print("dataset 2 size: %s samples" % data_2.len)

    return iterator_1, iterator_2


def generate_model(opt):

    model = Transformer(
        n_src_vocab=opt.src_dim,
        n_trg_vocab=opt.trg_dim,
        d_k=opt.d_k,
        d_v=opt.d_v,
        d_model=opt.d_model,
        d_word_vec=opt.d_word_vec,
        d_inner=opt.d_inner_hid,
        n_layers=opt.n_layers,
        n_head=opt.n_head,
        n_position=opt.seq_length,
        dropout=opt.dropout).cuda()

    return model


def cal_loss(pred, real_value):
    # Calculate cross entropy loss, apply label smoothing if needed.
    loss_func = torch.nn.MSELoss(reduction="mean")
    loss = loss_func(pred, real_value)

    return loss


def main():

    opt = generate_para()
    # all_models = os.listdir("./model")
    training_data, validation_data = prepare_dataloaders(opt)
    device = torch.device('cuda' if opt.cuda else 'cpu')

    transformer = generate_model(opt)
    transformer = torch.nn.DataParallel(transformer).cuda()

    f = open("valid_record.csv", "a")

    # for file in all_models:
    opt.checkpoint_load = opt.series
    opt.folder = opt.checkpoint_load.rstrip("chkpt").rstrip("best.").lstrip("model").lstrip("_").rstrip("_")
    checkpoint = torch.load("./model/%s" % opt.checkpoint_load)
    transformer.load_state_dict(checkpoint['model'])

    loss_1 = eval_epoch(transformer, training_data, device, opt)
    loss_2 = eval_epoch(transformer, validation_data, device, opt)
    print(opt.folder, ":", loss_1, loss_2)

    f.write("%s,%s,%s\n" % (opt.folder, loss_1, loss_2))

    f.close()


if __name__ == '__main__':
    main()
