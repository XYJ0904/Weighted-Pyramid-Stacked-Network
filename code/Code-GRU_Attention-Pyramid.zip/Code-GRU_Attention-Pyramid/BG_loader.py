from glob import glob
import torch
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
from torch.utils.data.dataloader import default_collate
import re
import numpy as np
import os
import random as rd
from scipy.io import loadmat


class BGDataset_Labled(Dataset):
    def __init__(self, root_path, mat_file, key_X, key_Y, file_series=None):
        raw_data = loadmat("%s/%s" % (root_path, mat_file))
        X = raw_data[key_X]
        Y = raw_data[key_Y]

        if file_series is not None:
            X = X[file_series]
            Y = Y[file_series]

        self.len = X.shape[0]
        assert self.len == Y.shape[0]

        self.X = torch.from_numpy(X)
        self.Y = torch.from_numpy(Y)

    def __len__(self):
        return self.len

    def __getitem__(self, index):
        return self.X[index], self.Y[index]



class BGDataset_Labled_Source(Dataset):
    def __init__(self, root_path, mat_file, file_series):
        raw_data = loadmat("%s/%s" % (root_path, mat_file))
        X = raw_data["X_data_new0"][file_series]
        Y = raw_data["y_data_new0"][file_series]
        self.len = X.shape[0]
        assert self.len == Y.shape[0]

        self.X = torch.from_numpy(X)
        self.Y = torch.from_numpy(Y)

    def __len__(self):
        return self.len

    def __getitem__(self, index):
        return self.X[index], self.Y[index]


if __name__ == '__main__':
    pass
