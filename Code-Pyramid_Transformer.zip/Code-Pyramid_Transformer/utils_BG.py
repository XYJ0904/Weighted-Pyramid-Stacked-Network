import random as rd
import numpy as np
from BG_loader import BGDataset_Labled
from transformer.Models import Transformer
from torch.utils.data import DataLoader
import torch
import os
import matplotlib.pyplot as plt
from torch.autograd import Variable


os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def prepare_dataloaders(opt):

    training_data, validation_data, train_len, valid_len = prepare_labled_dataloaders(opt)

    print("training dataset size: %s samples" % train_len)
    print("validation dataset size: %s samples" % valid_len)

    return training_data, validation_data


def prepare_labled_dataloaders(opt):
    batch_size = opt.batch_size

    train_data = BGDataset_Labled(opt.root_path, opt.mat_file, opt.key_X_train, opt.key_y_train)
    validate_data = BGDataset_Labled(opt.root_path, opt.mat_file, opt.key_X_valid, opt.key_y_valid)

    # test_data = SHMData(path, "test", PCA_dim, feature_dim, feature_dim, label_dim)
    train_iterator = DataLoader(train_data, batch_size=batch_size, shuffle=True, num_workers=0)
    val_iterator = DataLoader(validate_data, batch_size=batch_size, shuffle=False, num_workers=0)

    return train_iterator, val_iterator, train_data.len, validate_data.len


def generate_model(opt, teacher=False):

    model = Transformer(
        n_src_vocab=opt.src_dim,
        n_trg_vocab=opt.trg_dim,
        d_k=opt.d_k,
        d_v=opt.d_v,
        d_model=opt.d_model,
        d_word_vec=opt.d_word_vec,
        d_inner=opt.d_inner_hid,
        n_layers=opt.n_layers,
        n_head=opt.n_head,
        n_position=opt.seq_length,
        dropout=opt.dropout).cuda()

    if teacher:
        for param in model.parameters():
            param.detach_()

    return model


def cal_loss(pred, real_value):
    # Calculate cross entropy loss, apply label smoothing if needed.
    loss_func = torch.nn.MSELoss(reduction="mean")
    loss = loss_func(pred, real_value)

    return loss


def update_model_T(model_S, model_T, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for param_T, param_S in zip(model_T.parameters(), model_S.parameters()):
        param_T.data.mul_(alpha).add_(1 - alpha, param_S.data)

