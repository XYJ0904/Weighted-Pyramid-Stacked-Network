import argparse
import math
import time
import numpy as np
import random as rd
import matplotlib.pyplot as plt
import os
import torch
import torch.nn.functional as F
import torch.optim as optim
import copy
from torch.autograd import Variable
from utils_BG_pred import *

global_step = 0
os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def generate_para():
    global global_step
    parser = argparse.ArgumentParser()

    opt = parser.parse_args()
    opt.log = True
    opt.save_mode = "best"

    opt.root_path = "D:/杂活/20220609 自纠偏论文推送及数据开源/数据开源/Dataset" # path to be revised
    opt.mat_file = "data_Huang_final.mat" # file name to be revised

    opt.key_X_1 = "X_valid"
    opt.key_y_1 = "y_valid"
    opt.key_X_2 = "X_test"
    opt.key_y_2 = "y_test"
    opt.random_seed = 1

    opt.src_dim = 1  # Dataset information
    opt.trg_dim = 1
    opt.seq_length = 2000

    opt.batch_size = 2

    opt.d_model = 100 # network architecture information
    opt.d_word_vec = opt.d_model
    opt.d_inner_hid = 200
    opt.d_k = 50
    opt.d_v = 50
    opt.LR = 3e-2
    opt.n_head = 2
    opt.n_layers = 1

    return opt


def write_result(folder_series, series, input, output, pred):
    input = input.detach().cpu().squeeze(0).numpy()
    output = output.detach().cpu().squeeze(0).numpy()
    pred = pred.detach().cpu().squeeze(0).numpy()

    if not os.path.exists("./pred_result_%s" % folder_series):
        os.mkdir("./pred_result_%s" % folder_series)

    final_result = np.hstack((input, output, pred))
    np.savetxt("./pred_result_%s/%s.csv" % (folder_series, series), final_result, delimiter=",", fmt="%s")


def eval_epoch(model, validation_data, opt):
    ''' Epoch operation in evaluation phase '''
    model.eval()

    with torch.no_grad():
        # for batch in tqdm(validation_data, mininterval=2, desc=desc, leave=False):
        total_loss = 0.0
        step_valid = 0
        count = 0

        for src_seq_v, trg_seq_v in validation_data:

            src_seq_v = src_seq_v.cuda().float()
            trg_seq_v = trg_seq_v.cuda().float()
            # question = question.to(device)
            trg_seq_dis_v = torch.zeros(trg_seq_v.size()).float()
            trg_seq_dis_v[:, 1:, :] = trg_seq_v[:, :-1, :]
            trg_seq_dis_v = trg_seq_dis_v.cuda()

            pred_seq_v = model(src_seq_v, trg_seq_dis_v)
            # pred_seq_v = pred_seq_v.unsqueeze(2)
            loss = cal_loss(pred_seq_v, trg_seq_v)

            total_loss += loss.item() * src_seq_v.size(0)
            step_valid += src_seq_v.size(0)

            for number in range(src_seq_v.size(0)): # writting results in files
                input = src_seq_v[number, :, :]
                output = trg_seq_v[number, :, :]
                pred = pred_seq_v[number, :, :]

                write_result(opt.folder, count, input, output, pred)
                count += 1

    loss_average_1 = total_loss / step_valid

    return loss_average_1


def main():

    opt = generate_para()
    all_models = ["model_best.chkpt"]
    data_1, data_2 = prepare_dataloaders(opt) # loading datasets

    transformer = generate_model(opt, teacher=False)
    transformer = torch.nn.DataParallel(transformer).cuda()

    f = open("record.csv", "w")

    for file in all_models:
        opt.checkpoint_load = file
        opt.folder = opt.checkpoint_load.rstrip("chkpt")
        checkpoint = torch.load("./model/%s" % opt.checkpoint_load)
        transformer.load_state_dict(checkpoint['model'])

        loss_1 = eval_epoch(transformer, data_1, opt) # Validation
        loss_2 = eval_epoch(transformer, data_2, opt) # Testing
        print(opt.folder, ":", loss_1, loss_2)

        f.write("%s,%s,%s\n" % (opt.folder, loss_1, loss_2))
    f.close()


if __name__ == '__main__':
    main()
