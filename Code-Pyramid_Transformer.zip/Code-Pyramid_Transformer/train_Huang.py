import argparse
import time
import random as rd
import os
import torch
import torch.optim as optim
from transformer.Optim import ScheduledOptim
from utils_BG import *

global_step = 0
os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def generate_para():
    global global_step
    parser = argparse.ArgumentParser()

    opt = parser.parse_args()

    opt.root_path = "D:/杂活/20220609 自纠偏论文推送及数据开源/数据开源/Dataset" # path to be revised
    opt.mat_file = "data_Huang_final.mat" # file name to be revised

    opt.key_X_train = "X_train"  # Dataset information
    opt.key_y_train = "y_train"
    opt.key_X_valid = "X_valid"
    opt.key_y_valid = "y_valid"

    opt.seq_length = 2000  # Sequence length in the dataset
    opt.src_dim = 1
    opt.trg_dim = 1

    opt.batch_size = 2
    opt.epoch = 50000
    opt.n_warmup_steps = 30

    opt.n_head = 2 # network architecture
    opt.n_layers = 2
    opt.d_model = 100
    opt.d_word_vec = opt.d_model
    opt.d_inner_hid = int(opt.d_model * 2)
    opt.d_k = int(opt.d_model / opt.n_head)
    opt.d_v = opt.d_k
    opt.dropout = 0.005
    opt.LR = 1e-2

    opt.series = "Trans_Huang_%s_%s_%s_%s_%s_%.2f"\
                 % (opt.n_head, opt.n_layers, opt.batch_size, opt.d_model, opt.LR, rd.random())  # name of the saved models

    print("Training model with series %s" % opt.series)

    opt.log_name = "./log/log_%s" % opt.series
    opt.save_model_name = "./model/model_%s" % opt.series

    if not os.path.exists("./log"):
        os.mkdir("./log")
    if not os.path.exists("./model"):
        os.mkdir("./model")

    return opt


def generate_random_noise(size_src):

    random_noise = torch.rand(size_src)
    random_noise = random_noise.cuda()
    return random_noise


def get_teacher_rate(epoch):
    teacher_force_min = 0.010
    max_step = 2000
    ratio = min(1, max((epoch - max_step) / max_step, teacher_force_min))
    return ratio


def train_epoch(model_S, training_data, optimizer, opt, epoch):

    model_S.train()
    loss_pred_only = 0

    step = 0
    for src_seq, trg_seq in training_data:

        src_seq = src_seq.cuda().float()
        trg_seq = trg_seq.cuda().float()

        optimizer.zero_grad()

        trg_seq_dislocation = torch.zeros(trg_seq.size()).float()
        trg_seq_dislocation[:, 1:, :] = trg_seq[:, :-1, :]
        trg_seq_dislocation = trg_seq_dislocation.cuda()
        pred_labeled = model_S(src_seq, trg_seq_dislocation)
        loss = cal_loss(pred_labeled, trg_seq)

        loss.backward()
        # optimizer.step()
        optimizer.step_without_update_lr()
        loss_pred_only += loss.item() * src_seq.size(0)
        step += src_seq.size(0)

    optimizer.update_lr()
    loss_pred_average = loss_pred_only / step

    return loss_pred_average


def eval_epoch(model, validation_data, opt, epoch):
    ''' Epoch operation in evaluation phase '''
    model.eval()

    with torch.no_grad():
        # for batch in tqdm(validation_data, mininterval=2, desc=desc, leave=False):
        total_loss = 0.0
        step_valid = 0
        for src_seq_v, trg_seq_v in validation_data:
            src_seq_v = src_seq_v.cuda().float()
            trg_seq_v = trg_seq_v.cuda().float()
            # question = question.to(device)
            trg_seq_dis_v = torch.zeros(trg_seq_v.size()).float()
            trg_seq_dis_v[:, 1:, :] = trg_seq_v[:, :-1, :]
            # trg_seq_dis_v[:, 0, :] = trg_seq_dis_v[:, 1, :]
            trg_seq_dis_v = trg_seq_dis_v.cuda()

            pred_seq_v = model(src_seq_v, trg_seq_dis_v)
            loss = cal_loss(pred_seq_v, trg_seq_v)

            total_loss += loss.item() * src_seq_v.size(0)
            step_valid += src_seq_v.size(0)

    loss_average_1 = total_loss / step_valid

    return loss_average_1


def train(model_S, training_data, validation_data, optimizer, opt):
    ''' Start training '''

    log_file = opt.log_name + '.log'
    print('[Info] Training performance will be written to file: {}'.format(log_file))
    with open(log_file, 'w') as log_f:
        log_f.write('epoch, train_loss, valid_loss\n')

    def print_performances(header, loss, start_time):
        print('  - {header:15} : {loss: 8.5f}, ' \
              'elapse: {elapse:3.3f} min'.format(header=f"({header})", loss=loss * 1000,
                                                 elapse=(time.time() - start_time) / 60))

    valid_losses = []
    valid_losses_strict = []
    for epoch_i in range(opt.epoch):
        print('[ Epoch', epoch_i, ']')

        start = time.time()
        train_loss = train_epoch(model_S, training_data, optimizer, opt, epoch_i)
        print_performances('Training Loss', train_loss, start)

        start = time.time()
        valid_loss = eval_epoch(model_S, validation_data, opt, epoch_i)
        print_performances('Validation Loss', valid_loss, start)

        valid_losses += [valid_loss]

        checkpoint = {'epoch': epoch_i, 'settings': opt, 'model': model_S.state_dict()}

        model_name = opt.save_model_name + '_best.chkpt'
        if valid_loss <= min(valid_losses):
            torch.save(checkpoint, model_name)
            print('    - [Info] The checkpoint file has been updated.')

        with open(log_file, 'a') as log_f:
            log_f.write(
                '{epoch: d},{train_loss: 8.10f},{valid_loss: 8.10f}\n'.format(
                    epoch=epoch_i, train_loss=train_loss, valid_loss=valid_loss))


def main():
    opt = generate_para()
    training_data, validation_data = prepare_dataloaders(opt)

    transformer = generate_model(opt, teacher=False)
    transformer = torch.nn.DataParallel(transformer).cuda()

    optimizer = ScheduledOptim(
        optim.Adam(transformer.parameters(), lr=opt.LR, betas=(0.9, 0.99), eps=1e-09),
        opt.LR, opt.d_model, opt.n_warmup_steps)

    train(transformer, training_data, validation_data, optimizer, opt)


if __name__ == '__main__':
    main()
