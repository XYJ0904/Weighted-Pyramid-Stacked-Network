import random as rd
import numpy as np
from BG_loader import BGDataset_Labled
from transformer.Models import Transformer
from torch.utils.data import DataLoader
import torch
import os
import matplotlib.pyplot as plt
from torch.autograd import Variable


os.environ['CUDA_VISIBLE_DEVICES'] = '0'

def prepare_dataloaders(opt):

    data_1, data_2, len_1, len_2 = prepare_labled_dataloaders(opt)
    # unlabeled_data, unlabeled_len = prepare_unlabeled_dataloaders(opt)
    print("dataset 1 size: %s samples" % len_1)
    print("dataset 2 size: %s samples" % len_2)

    return data_1, data_2


def prepare_labled_dataloaders(opt):
    batch_size = opt.batch_size

    data_1 = BGDataset_Labled(opt.root_path, opt.mat_file, opt.key_X_1, opt.key_y_1)
    data_2 = BGDataset_Labled(opt.root_path, opt.mat_file, opt.key_X_2, opt.key_y_2)

    # test_data = SHMData(path, "test", PCA_dim, feature_dim, feature_dim, label_dim)
    iterator_1 = DataLoader(data_1, batch_size=batch_size, shuffle=True, num_workers=0)
    iterator_2 = DataLoader(data_2, batch_size=batch_size, shuffle=False, num_workers=0)

    return iterator_1, iterator_2, data_1.len, data_2.len


def generate_model(opt, teacher=False):

    model = Transformer(
        n_src_vocab=opt.src_dim,
        n_trg_vocab=opt.trg_dim,
        d_k=opt.d_k,
        d_v=opt.d_v,
        d_model=opt.d_model,
        d_word_vec=opt.d_word_vec,
        d_inner=opt.d_inner_hid,
        n_layers=opt.n_layers,
        n_head=opt.n_head,
        n_position=opt.seq_length,
        dropout=0.0).cuda()

    if teacher:
        for param in model.parameters():
            param.detach_()

    return model


def cal_loss(pred, real_value):
    # Calculate cross entropy loss, apply label smoothing if needed.
    loss_func = torch.nn.MSELoss(reduction="mean")
    loss = loss_func(pred, real_value)

    return loss
